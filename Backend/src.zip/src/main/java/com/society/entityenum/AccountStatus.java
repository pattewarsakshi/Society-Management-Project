package com.society.entityenum;

public enum AccountStatus {
    PENDING,
    ACTIVE,
    REJECTED
}
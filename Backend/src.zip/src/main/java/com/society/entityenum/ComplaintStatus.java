package com.society.entityenum;

public enum ComplaintStatus {
	OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED,
    REJECTED

}

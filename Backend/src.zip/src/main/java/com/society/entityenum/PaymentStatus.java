package com.society.entityenum;

public enum PaymentStatus {
    PENDING,
    APPROVAL_PENDING,
    PAID,
    REJECTED
}

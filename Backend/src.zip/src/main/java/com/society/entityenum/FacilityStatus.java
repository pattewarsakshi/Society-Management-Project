package com.society.entityenum;

public enum FacilityStatus {
	ACTIVE,
    MAINTENANCE,
    CLOSED
}

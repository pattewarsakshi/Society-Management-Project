package com.society.entityenum;

public enum FacilityName {
	 GYM,
	    SWIMMING_POOL,
	    CLUB_HOUSE,
	    COMMUNITY_HALL,
	    GARDEN,
	    PLAYGROUND,
	    PARKING,
	    TENNIS_COURT
}

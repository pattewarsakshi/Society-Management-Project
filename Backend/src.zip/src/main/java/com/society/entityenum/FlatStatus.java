package com.society.entityenum;

public enum FlatStatus {
    VACANT,
    OCCUPIED,
    UNDER_MAINTENANCE,
    SEALED

}

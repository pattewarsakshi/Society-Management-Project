package com.society.entityenum;

public enum ParkingStatus {
    FREE, OCCUPIED
}

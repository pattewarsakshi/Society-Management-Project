package com.society.entityenum;

public enum BookingStatus {
	 PENDING,
	    APPROVED,
	    REJECTED,
	    CANCELLED
}

package com.society.entityenum;

public enum ParkingType {
	VISITOR, RESIDENT
}
package com.society.entityenum;

public enum VisitPurpose {
    DELIVERY,
    FRIEND,
    RELATIVE,
    SERVICE,
    OTHER
}

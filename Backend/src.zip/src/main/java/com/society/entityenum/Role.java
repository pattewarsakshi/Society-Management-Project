package com.society.entityenum;

public enum Role {
	 ADMIN,
	    OWNER,
	    RESIDENT,
	    GUARD
}

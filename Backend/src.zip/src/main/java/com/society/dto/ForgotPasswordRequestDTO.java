package com.society.dto;

import lombok.Data;

@Data
public class ForgotPasswordRequestDTO {
 private String email;
}


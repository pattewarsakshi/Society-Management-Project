package com.society.dto;

import lombok.Data;

@Data
public class ProfileUpdateDTO {

    private String firstName;
    private String middleName;
    private String lastName;
    private String phone;
}

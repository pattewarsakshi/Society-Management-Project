package com.society.dto;

import lombok.Data;

@Data
public class AdminComplaintSearchDTO {
    private String towerName;
    private String flatNumber;
}

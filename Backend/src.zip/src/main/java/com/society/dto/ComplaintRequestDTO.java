package com.society.dto;

import lombok.Data;

@Data
public class ComplaintRequestDTO {
    private String complaintType;
    private String description;
}

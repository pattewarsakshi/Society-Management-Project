package com.society.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApproveUserRequestDTO {
    private Integer userId;
    private Integer flatId;
}

package com.society.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class GuardLoginDTO {

	
	
	    private String email;
	    private String password;
	}



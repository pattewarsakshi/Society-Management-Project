package com.society.dto;

import lombok.Data;

@Data
public class NoticeRequestDto {
    private String title;
    private String description;
}
